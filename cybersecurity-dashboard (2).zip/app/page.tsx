"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Scan, Network, Shield, Activity, Target, Zap } from "lucide-react"
import PortScanner from "./components/port-scanner"
import ScanResults from "./components/scan-results"
import PortDatabase from "./components/port-database"
import ScanHistory from "./components/scan-history"
import NetworkTools from "./components/network-tools"

export default function WebPortScanner() {
  const [activeTab, setActiveTab] = useState("scanner")
  const [scanResults, setScanResults] = useState<any[]>([])
  const [scanHistory, setScanHistory] = useState<any[]>([])

  const addToHistory = (scanData: any) => {
    const historyEntry = {
      id: Date.now(),
      timestamp: new Date().toLocaleString(),
      ...scanData,
    }
    setScanHistory((prev) => [historyEntry, ...prev.slice(0, 9)]) // Keep last 10 scans
  }

  const dashboardStats = [
    { label: "Total Scans", value: scanHistory.length.toString(), icon: Scan, color: "text-blue-400" },
    {
      label: "Open Ports Found",
      value: scanResults.filter((r) => r.status === "open").length.toString(),
      icon: Network,
      color: "text-green-400",
    },
    {
      label: "Filtered Ports",
      value: scanResults.filter((r) => r.status === "filtered").length.toString(),
      icon: Shield,
      color: "text-yellow-400",
    },
    {
      label: "Active Services",
      value: scanResults.filter((r) => r.service && r.status === "open").length.toString(),
      icon: Activity,
      color: "text-purple-400",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2 flex items-center gap-3">
            <Target className="w-10 h-10 text-blue-400" />
            Web Port Scanner
          </h1>
          <p className="text-slate-300">Professional network port scanning and service discovery tool</p>
        </div>

        {/* Dashboard Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {dashboardStats.map((stat, index) => {
            const Icon = stat.icon
            return (
              <Card key={index} className="bg-slate-800/50 border-slate-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-slate-400 text-sm">{stat.label}</p>
                      <p className="text-2xl font-bold text-white">{stat.value}</p>
                    </div>
                    <Icon className={`w-8 h-8 ${stat.color}`} />
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 bg-slate-800/50 border-slate-700">
            <TabsTrigger value="scanner" className="data-[state=active]:bg-blue-600">
              <Scan className="w-4 h-4 mr-2" />
              Scanner
            </TabsTrigger>
            <TabsTrigger value="results" className="data-[state=active]:bg-blue-600">
              <Activity className="w-4 h-4 mr-2" />
              Results
            </TabsTrigger>
            <TabsTrigger value="database" className="data-[state=active]:bg-blue-600">
              <Network className="w-4 h-4 mr-2" />
              Port DB
            </TabsTrigger>
            <TabsTrigger value="history" className="data-[state=active]:bg-blue-600">
              <Shield className="w-4 h-4 mr-2" />
              History
            </TabsTrigger>
            <TabsTrigger value="tools" className="data-[state=active]:bg-blue-600">
              <Zap className="w-4 h-4 mr-2" />
              Tools
            </TabsTrigger>
          </TabsList>

          <TabsContent value="scanner">
            <PortScanner onScanComplete={(results) => setScanResults(results)} onAddToHistory={addToHistory} />
          </TabsContent>

          <TabsContent value="results">
            <ScanResults results={scanResults} />
          </TabsContent>

          <TabsContent value="database">
            <PortDatabase />
          </TabsContent>

          <TabsContent value="history">
            <ScanHistory history={scanHistory} onClearHistory={() => setScanHistory([])} />
          </TabsContent>

          <TabsContent value="tools">
            <NetworkTools />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
