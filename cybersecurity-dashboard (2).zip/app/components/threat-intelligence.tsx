"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { RefreshCw, AlertTriangle, TrendingUp, Globe, Clock } from "lucide-react"

export default function ThreatIntelligence() {
  const [threats, setThreats] = useState<any[]>([])
  const [loading, setLoading] = useState(false)

  const mockThreats = [
    {
      id: "TI-2024-001",
      title: "New Ransomware Campaign Targeting Healthcare",
      severity: "critical",
      category: "Malware",
      source: "CISA",
      timestamp: "2 hours ago",
      description:
        "A new ransomware variant is actively targeting healthcare organizations with sophisticated phishing campaigns.",
      indicators: ["malicious-domain.com", "192.168.1.100", "suspicious.exe"],
      mitigation: "Block known IOCs, update email security filters, conduct user awareness training",
    },
    {
      id: "TI-2024-002",
      title: "Zero-Day Vulnerability in Popular Web Framework",
      severity: "high",
      category: "Vulnerability",
      source: "Security Researcher",
      timestamp: "6 hours ago",
      description:
        "Critical RCE vulnerability discovered in widely-used web framework affecting millions of applications.",
      indicators: ["CVE-2024-1234", "framework-v2.1.0"],
      mitigation: "Update to patched version immediately, implement WAF rules, monitor for exploitation attempts",
    },
    {
      id: "TI-2024-003",
      title: "State-Sponsored APT Group Targeting Financial Sector",
      severity: "high",
      category: "APT",
      source: "Threat Intelligence Firm",
      timestamp: "12 hours ago",
      description: "Advanced persistent threat group using novel techniques to infiltrate financial institutions.",
      indicators: ["apt-c2-server.net", "backdoor.dll", "spear-phishing emails"],
      mitigation: "Enhanced monitoring, network segmentation, employee security training",
    },
    {
      id: "TI-2024-004",
      title: "Cryptocurrency Mining Botnet Expansion",
      severity: "medium",
      category: "Botnet",
      source: "Cybersecurity Vendor",
      timestamp: "1 day ago",
      description: "Large-scale botnet expanding operations to include cryptocurrency mining on compromised systems.",
      indicators: ["mining-pool.evil", "cryptominer.exe", "suspicious network traffic"],
      mitigation: "Monitor for unusual CPU usage, block mining pools, update endpoint protection",
    },
    {
      id: "TI-2024-005",
      title: "Phishing Campaign Impersonating Cloud Services",
      severity: "medium",
      category: "Phishing",
      source: "Email Security Provider",
      timestamp: "2 days ago",
      description:
        "Sophisticated phishing campaign targeting cloud service credentials with convincing fake login pages.",
      indicators: ["fake-cloud-login.com", "credential harvesting", "social engineering"],
      mitigation: "User awareness training, implement MFA, email security controls",
    },
  ]

  const loadThreats = async () => {
    setLoading(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Randomize which threats to show
    const selectedThreats = mockThreats
      .sort(() => Math.random() - 0.5)
      .slice(0, Math.floor(Math.random() * 3) + 3)
      .map((threat) => ({
        ...threat,
        timestamp: getRandomTimestamp(),
      }))

    setThreats(selectedThreats)
    setLoading(false)
  }

  const getRandomTimestamp = () => {
    const timestamps = ["5 min ago", "1 hour ago", "3 hours ago", "8 hours ago", "1 day ago", "2 days ago"]
    return timestamps[Math.floor(Math.random() * timestamps.length)]
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "bg-purple-600"
      case "high":
        return "bg-red-600"
      case "medium":
        return "bg-yellow-600"
      case "low":
        return "bg-blue-600"
      default:
        return "bg-gray-600"
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Malware":
        return <AlertTriangle className="w-4 h-4" />
      case "APT":
        return <TrendingUp className="w-4 h-4" />
      case "Phishing":
        return <Globe className="w-4 h-4" />
      default:
        return <AlertTriangle className="w-4 h-4" />
    }
  }

  useEffect(() => {
    loadThreats()
  }, [])

  return (
    <Card className="bg-slate-800/50 border-slate-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              Threat Intelligence Feed
            </CardTitle>
            <CardDescription className="text-slate-400">Latest cybersecurity threats and indicators</CardDescription>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={loadThreats}
            disabled={loading}
            className="text-cyan-400 hover:text-cyan-300"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="p-4 bg-slate-700/30 rounded-lg animate-pulse">
                <div className="h-4 bg-slate-600 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-slate-600 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {threats.map((threat, index) => (
              <div key={index} className="p-4 bg-slate-700/30 rounded-lg border-l-4 border-l-orange-500">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    {getCategoryIcon(threat.category)}
                    <h5 className="text-white font-medium">{threat.title}</h5>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={getSeverityColor(threat.severity)}>{threat.severity.toUpperCase()}</Badge>
                    <Badge variant="outline" className="text-slate-300 border-slate-500">
                      {threat.category}
                    </Badge>
                  </div>
                </div>

                <div className="space-y-2 text-sm">
                  <p className="text-slate-300">{threat.description}</p>

                  <div className="flex items-center gap-4 text-xs text-slate-400">
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {threat.timestamp}
                    </div>
                    <div>Source: {threat.source}</div>
                    <div>ID: {threat.id}</div>
                  </div>

                  <div className="space-y-2">
                    <div>
                      <span className="text-slate-400 font-medium">Indicators of Compromise:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {threat.indicators.map((ioc: string, iocIndex: number) => (
                          <Badge key={iocIndex} variant="secondary" className="text-xs font-mono">
                            {ioc}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="p-3 bg-slate-600/30 rounded">
                      <span className="text-green-400 font-medium">Mitigation:</span>
                      <p className="text-green-300 text-xs mt-1">{threat.mitigation}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="p-4 bg-blue-900/20 border border-blue-700 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-blue-400" />
            <span className="text-blue-400 font-medium">Threat Intelligence Tips</span>
          </div>
          <ul className="text-blue-300 text-sm space-y-1">
            <li>• Monitor threat feeds regularly for emerging threats</li>
            <li>• Implement IOC blocking in security tools</li>
            <li>• Share threat intelligence with industry peers</li>
            <li>• Correlate threats with your environment</li>
            <li>• Update security controls based on new intelligence</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  )
}
