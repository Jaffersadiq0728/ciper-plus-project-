"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Scan, Play, Square, Settings, Target, Clock } from "lucide-react"

interface PortScannerProps {
  onScanComplete: (results: any[]) => void
  onAddToHistory: (scanData: any) => void
}

export default function PortScanner({ onScanComplete, onAddToHistory }: PortScannerProps) {
  const [target, setTarget] = useState("")
  const [scanType, setScanType] = useState("tcp-connect")
  const [portRange, setPortRange] = useState("1-1000")
  const [customPorts, setCustomPorts] = useState("")
  const [scanning, setScanning] = useState(false)
  const [progress, setProgress] = useState(0)
  const [currentPort, setCurrentPort] = useState(0)
  const [scanSpeed, setScanSpeed] = useState("normal")
  const [enableServiceDetection, setEnableServiceDetection] = useState(true)
  const [enableOSDetection, setEnableOSDetection] = useState(false)
  const [enableVersionDetection, setEnableVersionDetection] = useState(true)

  const commonPortRanges = [
    { label: "Top 100 Ports", value: "top-100" },
    { label: "Top 1000 Ports", value: "1-1000" },
    { label: "Well-known Ports (1-1023)", value: "1-1023" },
    { label: "All Ports (1-65535)", value: "1-65535" },
    { label: "Custom Range", value: "custom" },
  ]

  const scanTypes = [
    { value: "tcp-connect", label: "TCP Connect Scan", description: "Full TCP connection" },
    { value: "tcp-syn", label: "TCP SYN Scan", description: "Stealth half-open scan" },
    { value: "tcp-ack", label: "TCP ACK Scan", description: "Firewall detection" },
    { value: "udp", label: "UDP Scan", description: "UDP port scan" },
    { value: "tcp-fin", label: "TCP FIN Scan", description: "Stealth FIN scan" },
    { value: "tcp-null", label: "TCP NULL Scan", description: "Stealth NULL scan" },
  ]

  const commonPorts = [
    { port: 21, service: "FTP", protocol: "TCP", description: "File Transfer Protocol" },
    { port: 22, service: "SSH", protocol: "TCP", description: "Secure Shell" },
    { port: 23, service: "Telnet", protocol: "TCP", description: "Telnet Protocol" },
    { port: 25, service: "SMTP", protocol: "TCP", description: "Simple Mail Transfer Protocol" },
    { port: 53, service: "DNS", protocol: "TCP/UDP", description: "Domain Name System" },
    { port: 80, service: "HTTP", protocol: "TCP", description: "Hypertext Transfer Protocol" },
    { port: 110, service: "POP3", protocol: "TCP", description: "Post Office Protocol v3" },
    { port: 143, service: "IMAP", protocol: "TCP", description: "Internet Message Access Protocol" },
    { port: 443, service: "HTTPS", protocol: "TCP", description: "HTTP Secure" },
    { port: 993, service: "IMAPS", protocol: "TCP", description: "IMAP over SSL" },
    { port: 995, service: "POP3S", protocol: "TCP", description: "POP3 over SSL" },
    { port: 3389, service: "RDP", protocol: "TCP", description: "Remote Desktop Protocol" },
    { port: 5432, service: "PostgreSQL", protocol: "TCP", description: "PostgreSQL Database" },
    { port: 3306, service: "MySQL", protocol: "TCP", description: "MySQL Database" },
  ]

  const generatePortList = (range: string) => {
    if (range === "top-100") {
      return [21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 443, 993, 995, 1723, 3306, 3389, 5432, 5900, 8080]
    }

    if (range.includes("-")) {
      const [start, end] = range.split("-").map(Number)
      const ports = []
      for (let i = start; i <= Math.min(end, 1000); i++) {
        // Limit to 1000 for demo
        ports.push(i)
      }
      return ports
    }

    return range.split(",").map(Number).filter(Boolean)
  }

  const simulatePortScan = async () => {
    if (!target) return

    setScanning(true)
    setProgress(0)
    setCurrentPort(0)

    const ports = customPorts ? customPorts.split(",").map(Number).filter(Boolean) : generatePortList(portRange)

    const results: any[] = []
    const scanStartTime = Date.now()

    // Simulate scanning each port
    for (let i = 0; i < ports.length; i++) {
      const port = ports[i]
      setCurrentPort(port)
      setProgress((i / ports.length) * 100)

      // Simulate scan delay based on speed
      const delay = scanSpeed === "fast" ? 50 : scanSpeed === "normal" ? 100 : 200
      await new Promise((resolve) => setTimeout(resolve, delay))

      // Simulate port status (random but weighted)
      const isOpen = Math.random() > 0.85 // 15% chance of being open
      const isFiltered = !isOpen && Math.random() > 0.7 // 30% chance of being filtered if not open

      const commonPort = commonPorts.find((p) => p.port === port)

      if (isOpen || isFiltered) {
        const result = {
          port,
          status: isOpen ? "open" : "filtered",
          protocol: scanType.includes("udp") ? "UDP" : "TCP",
          service: commonPort?.service || "unknown",
          version: enableVersionDetection && isOpen ? generateVersion(commonPort?.service) : "",
          banner: isOpen ? generateBanner(commonPort?.service) : "",
          responseTime: Math.floor(Math.random() * 100) + 10,
          scanType,
        }
        results.push(result)
      }
    }

    const scanEndTime = Date.now()
    const scanDuration = scanEndTime - scanStartTime

    // Add scan to history
    onAddToHistory({
      target,
      scanType,
      portRange: customPorts || portRange,
      portsScanned: ports.length,
      openPorts: results.filter((r) => r.status === "open").length,
      filteredPorts: results.filter((r) => r.status === "filtered").length,
      duration: scanDuration,
      results,
    })

    onScanComplete(results)
    setScanning(false)
    setProgress(100)
  }

  const generateVersion = (service?: string) => {
    const versions = {
      SSH: ["OpenSSH 8.9", "OpenSSH 7.4", "OpenSSH 8.2"],
      HTTP: ["Apache/2.4.41", "nginx/1.18.0", "Microsoft-IIS/10.0"],
      HTTPS: ["Apache/2.4.41", "nginx/1.18.0", "Microsoft-IIS/10.0"],
      FTP: ["vsftpd 3.0.3", "ProFTPD 1.3.6", "Microsoft ftpd"],
      SMTP: ["Postfix smtpd", "Microsoft ESMTP", "Exim 4.94"],
      MySQL: ["MySQL 8.0.28", "MySQL 5.7.36", "MariaDB 10.6"],
      PostgreSQL: ["PostgreSQL 13.5", "PostgreSQL 12.9", "PostgreSQL 14.1"],
    }

    const serviceVersions = versions[service as keyof typeof versions]
    return serviceVersions ? serviceVersions[Math.floor(Math.random() * serviceVersions.length)] : ""
  }

  const generateBanner = (service?: string) => {
    const banners = {
      SSH: "SSH-2.0-OpenSSH_8.9",
      HTTP: "Server: Apache/2.4.41 (Ubuntu)",
      HTTPS: "Server: nginx/1.18.0",
      FTP: "220 Welcome to FTP service",
      SMTP: "220 mail.example.com ESMTP Postfix",
    }

    return banners[service as keyof typeof banners] || ""
  }

  const stopScan = () => {
    setScanning(false)
    setProgress(0)
    setCurrentPort(0)
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Scan Configuration */}
      <div className="lg:col-span-2 space-y-6">
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Target className="w-5 h-5" />
              Scan Configuration
            </CardTitle>
            <CardDescription className="text-slate-400">Configure your port scan parameters</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-white text-sm font-medium">Target Host</label>
                <Input
                  placeholder="192.168.1.1 or example.com"
                  value={target}
                  onChange={(e) => setTarget(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white"
                  disabled={scanning}
                />
              </div>

              <div className="space-y-2">
                <label className="text-white text-sm font-medium">Scan Type</label>
                <Select value={scanType} onValueChange={setScanType} disabled={scanning}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {scanTypes.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        <div>
                          <div className="font-medium">{type.label}</div>
                          <div className="text-xs text-slate-400">{type.description}</div>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-white text-sm font-medium">Port Range</label>
                <Select value={portRange} onValueChange={setPortRange} disabled={scanning}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {commonPortRanges.map((range) => (
                      <SelectItem key={range.value} value={range.value}>
                        {range.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-white text-sm font-medium">Scan Speed</label>
                <Select value={scanSpeed} onValueChange={setScanSpeed} disabled={scanning}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="slow">Slow (Stealthy)</SelectItem>
                    <SelectItem value="normal">Normal</SelectItem>
                    <SelectItem value="fast">Fast (Aggressive)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {portRange === "custom" && (
              <div className="space-y-2">
                <label className="text-white text-sm font-medium">Custom Ports</label>
                <Input
                  placeholder="80,443,8080 or 1-100"
                  value={customPorts}
                  onChange={(e) => setCustomPorts(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white"
                  disabled={scanning}
                />
              </div>
            )}

            <div className="space-y-3">
              <label className="text-white text-sm font-medium">Scan Options</label>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="service-detection"
                    checked={enableServiceDetection}
                    onCheckedChange={setEnableServiceDetection}
                    disabled={scanning}
                  />
                  <label htmlFor="service-detection" className="text-slate-300 text-sm">
                    Enable service detection
                  </label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="version-detection"
                    checked={enableVersionDetection}
                    onCheckedChange={setEnableVersionDetection}
                    disabled={scanning}
                  />
                  <label htmlFor="version-detection" className="text-slate-300 text-sm">
                    Enable version detection
                  </label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="os-detection"
                    checked={enableOSDetection}
                    onCheckedChange={setEnableOSDetection}
                    disabled={scanning}
                  />
                  <label htmlFor="os-detection" className="text-slate-300 text-sm">
                    Enable OS detection (experimental)
                  </label>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              {!scanning ? (
                <Button onClick={simulatePortScan} disabled={!target} className="bg-blue-600 hover:bg-blue-700 flex-1">
                  <Play className="w-4 h-4 mr-2" />
                  Start Scan
                </Button>
              ) : (
                <Button onClick={stopScan} variant="destructive" className="flex-1">
                  <Square className="w-4 h-4 mr-2" />
                  Stop Scan
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Scan Progress */}
        {scanning && (
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Scan className="w-5 h-5 animate-spin" />
                Scanning in Progress
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-300">
                    Scanning {target} - Current port: {currentPort}
                  </span>
                  <span className="text-slate-300">{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="text-slate-300">
                  <span className="text-slate-400">Scan Type:</span>{" "}
                  {scanTypes.find((t) => t.value === scanType)?.label}
                </div>
                <div className="text-slate-300">
                  <span className="text-slate-400">Speed:</span> {scanSpeed}
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Quick Actions & Info */}
      <div className="space-y-6">
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Quick Presets
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button
              variant="outline"
              className="w-full justify-start bg-transparent"
              onClick={() => {
                setTarget("127.0.0.1")
                setPortRange("top-100")
                setScanType("tcp-connect")
              }}
              disabled={scanning}
            >
              Localhost Quick Scan
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start bg-transparent"
              onClick={() => {
                setPortRange("1-1023")
                setScanType("tcp-syn")
                setEnableServiceDetection(true)
              }}
              disabled={scanning}
            >
              Well-known Ports
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start bg-transparent"
              onClick={() => {
                setCustomPorts("80,443,8080,8443")
                setPortRange("custom")
                setScanType("tcp-connect")
              }}
              disabled={scanning}
            >
              Web Services Scan
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start bg-transparent"
              onClick={() => {
                setCustomPorts("21,22,23,25,53,110,143,993,995")
                setPortRange("custom")
                setScanType("tcp-connect")
              }}
              disabled={scanning}
            >
              Common Services
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white text-sm">Scan Types Info</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {scanTypes.slice(0, 4).map((type) => (
              <div key={type.value} className="text-xs">
                <div className="text-white font-medium">{type.label}</div>
                <div className="text-slate-400">{type.description}</div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white text-sm flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Scan Statistics
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">Ports per second:</span>
              <span className="text-white">{scanSpeed === "fast" ? "20" : scanSpeed === "normal" ? "10" : "5"}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Stealth level:</span>
              <span className="text-white">
                {scanType.includes("syn") ? "High" : scanType.includes("connect") ? "Low" : "Medium"}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Detection risk:</span>
              <Badge variant={scanSpeed === "fast" ? "destructive" : "secondary"} className="text-xs">
                {scanSpeed === "fast" ? "High" : "Low"}
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
