"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Copy, Check, Hash, FileText } from "lucide-react"

export default function HashGenerator() {
  const [input, setInput] = useState("")
  const [algorithm, setAlgorithm] = useState("SHA-256")
  const [hashes, setHashes] = useState<{ [key: string]: string }>({})
  const [copied, setCopied] = useState("")
  const [hashToVerify, setHashToVerify] = useState("")
  const [verificationResult, setVerificationResult] = useState<string | null>(null)

  const generateHash = async (text: string, algo: string) => {
    const encoder = new TextEncoder()
    const data = encoder.encode(text)

    let hashBuffer: ArrayBuffer

    switch (algo) {
      case "SHA-1":
        hashBuffer = await crypto.subtle.digest("SHA-1", data)
        break
      case "SHA-256":
        hashBuffer = await crypto.subtle.digest("SHA-256", data)
        break
      case "SHA-384":
        hashBuffer = await crypto.subtle.digest("SHA-384", data)
        break
      case "SHA-512":
        hashBuffer = await crypto.subtle.digest("SHA-512", data)
        break
      default:
        return ""
    }

    const hashArray = Array.from(new Uint8Array(hashBuffer))
    return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")
  }

  const generateAllHashes = async () => {
    if (!input) return

    const algorithms = ["SHA-1", "SHA-256", "SHA-384", "SHA-512"]
    const newHashes: { [key: string]: string } = {}

    for (const algo of algorithms) {
      newHashes[algo] = await generateHash(input, algo)
    }

    setHashes(newHashes)
  }

  const copyToClipboard = async (text: string, algo: string) => {
    await navigator.clipboard.writeText(text)
    setCopied(algo)
    setTimeout(() => setCopied(""), 2000)
  }

  const verifyHash = async () => {
    if (!input || !hashToVerify) return

    const currentHash = await generateHash(input, algorithm)
    setVerificationResult(currentHash.toLowerCase() === hashToVerify.toLowerCase() ? "match" : "no-match")
  }

  const hashExamples = [
    {
      input: "Hello, World!",
      description: "Simple greeting text",
    },
    {
      input: "password123",
      description: "Common password (never use this!)",
    },
    {
      input: JSON.stringify({ user: "admin", timestamp: Date.now() }),
      description: "JSON data structure",
    },
  ]

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Hash className="w-5 h-5" />
            Hash Generator
          </CardTitle>
          <CardDescription className="text-slate-400">
            Generate cryptographic hashes for data integrity verification
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Enter text to hash..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="bg-slate-700 border-slate-600 text-white min-h-[100px]"
          />

          <Button onClick={generateAllHashes} disabled={!input} className="w-full bg-cyan-600 hover:bg-cyan-700">
            Generate Hashes
          </Button>

          {Object.keys(hashes).length > 0 && (
            <div className="space-y-4">
              <h4 className="text-white font-medium">Generated Hashes:</h4>
              {Object.entries(hashes).map(([algo, hash]) => (
                <div key={algo} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Badge variant="outline" className="text-cyan-400 border-cyan-400">
                      {algo}
                    </Badge>
                    <Button variant="ghost" size="sm" onClick={() => copyToClipboard(hash, algo)}>
                      {copied === algo ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                    </Button>
                  </div>
                  <div className="p-3 bg-slate-700/30 rounded font-mono text-sm text-slate-300 break-all">{hash}</div>
                </div>
              ))}
            </div>
          )}

          <div className="space-y-2">
            <h4 className="text-white font-medium">Quick Examples:</h4>
            {hashExamples.map((example, index) => (
              <Button
                key={index}
                variant="ghost"
                className="w-full justify-start text-left h-auto p-3"
                onClick={() => setInput(example.input)}
              >
                <div>
                  <p className="text-white text-sm font-mono">{example.input}</p>
                  <p className="text-slate-400 text-xs">{example.description}</p>
                </div>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Hash Verification
          </CardTitle>
          <CardDescription className="text-slate-400">Verify data integrity by comparing hashes</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-white text-sm">Original Data:</label>
            <Textarea
              placeholder="Enter original data..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white"
            />
          </div>

          <div className="space-y-2">
            <label className="text-white text-sm">Hash Algorithm:</label>
            <Select value={algorithm} onValueChange={setAlgorithm}>
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="SHA-1">SHA-1</SelectItem>
                <SelectItem value="SHA-256">SHA-256</SelectItem>
                <SelectItem value="SHA-384">SHA-384</SelectItem>
                <SelectItem value="SHA-512">SHA-512</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-white text-sm">Hash to Verify:</label>
            <Textarea
              placeholder="Paste hash to verify..."
              value={hashToVerify}
              onChange={(e) => setHashToVerify(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white font-mono"
            />
          </div>

          <Button
            onClick={verifyHash}
            disabled={!input || !hashToVerify}
            className="w-full bg-purple-600 hover:bg-purple-700"
          >
            Verify Hash
          </Button>

          {verificationResult && (
            <div
              className={`p-4 rounded-lg border ${
                verificationResult === "match" ? "bg-green-900/20 border-green-700" : "bg-red-900/20 border-red-700"
              }`}
            >
              <div className="flex items-center gap-2">
                {verificationResult === "match" ? (
                  <>
                    <Check className="w-4 h-4 text-green-400" />
                    <span className="text-green-400 font-medium">Hash Match!</span>
                  </>
                ) : (
                  <>
                    <Hash className="w-4 h-4 text-red-400" />
                    <span className="text-red-400 font-medium">Hash Mismatch</span>
                  </>
                )}
              </div>
              <p className={`text-sm mt-1 ${verificationResult === "match" ? "text-green-300" : "text-red-300"}`}>
                {verificationResult === "match"
                  ? "The data integrity is verified. The hash matches the original data."
                  : "The data has been modified or the hash is incorrect."}
              </p>
            </div>
          )}

          <div className="space-y-2">
            <h4 className="text-white font-medium">Hash Algorithm Info:</h4>
            <div className="text-sm text-slate-300 space-y-1">
              <p>
                <strong>SHA-1:</strong> 160-bit, deprecated for security
              </p>
              <p>
                <strong>SHA-256:</strong> 256-bit, widely used, secure
              </p>
              <p>
                <strong>SHA-384:</strong> 384-bit, high security
              </p>
              <p>
                <strong>SHA-512:</strong> 512-bit, maximum security
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
