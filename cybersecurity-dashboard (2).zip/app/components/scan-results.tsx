"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Activity,
  Search,
  Filter,
  Download,
  Copy,
  Check,
  AlertTriangle,
  Shield,
  Network,
  Clock,
  Server,
} from "lucide-react"

interface ScanResultsProps {
  results: any[]
}

export default function ScanResults({ results }: ScanResultsProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [protocolFilter, setProtocolFilter] = useState("all")
  const [copied, setCopied] = useState(false)

  const filteredResults = results.filter((result) => {
    const matchesSearch =
      result.port.toString().includes(searchTerm) ||
      result.service.toLowerCase().includes(searchTerm.toLowerCase()) ||
      result.version.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || result.status === statusFilter
    const matchesProtocol = protocolFilter === "all" || result.protocol === protocolFilter

    return matchesSearch && matchesStatus && matchesProtocol
  })

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "open":
        return <Network className="w-4 h-4 text-green-400" />
      case "closed":
        return <Shield className="w-4 h-4 text-red-400" />
      case "filtered":
        return <AlertTriangle className="w-4 h-4 text-yellow-400" />
      default:
        return <Activity className="w-4 h-4 text-slate-400" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "open":
        return <Badge className="bg-green-600">Open</Badge>
      case "closed":
        return <Badge variant="destructive">Closed</Badge>
      case "filtered":
        return <Badge variant="secondary">Filtered</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  const getRiskLevel = (port: number, service: string, status: string) => {
    if (status !== "open") return "low"

    const highRiskPorts = [21, 23, 135, 139, 445, 1433, 3389, 5432, 3306]
    const mediumRiskPorts = [25, 110, 143, 993, 995, 8080, 8443]

    if (highRiskPorts.includes(port)) return "high"
    if (mediumRiskPorts.includes(port)) return "medium"
    return "low"
  }

  const exportResults = () => {
    const csvContent = [
      "Port,Protocol,Status,Service,Version,Response Time,Risk Level",
      ...filteredResults.map(
        (result) =>
          `${result.port},${result.protocol},${result.status},${result.service},${result.version},${result.responseTime}ms,${getRiskLevel(result.port, result.service, result.status)}`,
      ),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `port-scan-results-${new Date().toISOString().split("T")[0]}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  const copyResults = async () => {
    const textContent = filteredResults
      .map((result) => `${result.port}/${result.protocol} - ${result.status} - ${result.service} ${result.version}`)
      .join("\n")

    await navigator.clipboard.writeText(textContent)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const openPorts = results.filter((r) => r.status === "open").length
  const filteredPorts = results.filter((r) => r.status === "filtered").length
  const totalPorts = results.length

  return (
    <div className="space-y-6">
      {/* Results Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Open Ports</p>
                <p className="text-2xl font-bold text-green-400">{openPorts}</p>
              </div>
              <Network className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Filtered Ports</p>
                <p className="text-2xl font-bold text-yellow-400">{filteredPorts}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-yellow-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Total Scanned</p>
                <p className="text-2xl font-bold text-blue-400">{totalPorts}</p>
              </div>
              <Activity className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Results Table */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white flex items-center gap-2">
                <Activity className="w-5 h-5" />
                Scan Results ({filteredResults.length})
              </CardTitle>
              <CardDescription className="text-slate-400">
                Detailed port scan results and service information
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={copyResults} disabled={filteredResults.length === 0}>
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </Button>
              <Button variant="outline" size="sm" onClick={exportResults} disabled={filteredResults.length === 0}>
                <Download className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search ports, services..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white pl-10"
              />
            </div>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="open">Open</SelectItem>
                <SelectItem value="closed">Closed</SelectItem>
                <SelectItem value="filtered">Filtered</SelectItem>
              </SelectContent>
            </Select>

            <Select value={protocolFilter} onValueChange={setProtocolFilter}>
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                <SelectValue placeholder="Filter by protocol" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Protocols</SelectItem>
                <SelectItem value="TCP">TCP</SelectItem>
                <SelectItem value="UDP">UDP</SelectItem>
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              onClick={() => {
                setSearchTerm("")
                setStatusFilter("all")
                setProtocolFilter("all")
              }}
            >
              <Filter className="w-4 h-4 mr-2" />
              Clear
            </Button>
          </div>

          {/* Results List */}
          {filteredResults.length === 0 ? (
            <div className="text-center py-12">
              <Activity className="w-12 h-12 text-slate-600 mx-auto mb-4" />
              <p className="text-slate-400">
                {results.length === 0
                  ? "No scan results yet. Start a scan to see results here."
                  : "No results match your filters."}
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredResults.map((result, index) => {
                const riskLevel = getRiskLevel(result.port, result.service, result.status)
                return (
                  <div
                    key={index}
                    className="flex items-center justify-between p-4 bg-slate-700/30 rounded-lg border-l-4 border-l-blue-500"
                  >
                    <div className="flex items-center gap-4">
                      {getStatusIcon(result.status)}
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-white font-mono text-lg">
                            {result.port}/{result.protocol}
                          </span>
                          {getStatusBadge(result.status)}
                          <Badge
                            variant={
                              riskLevel === "high" ? "destructive" : riskLevel === "medium" ? "secondary" : "outline"
                            }
                            className="text-xs"
                          >
                            {riskLevel} risk
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 mt-1 text-sm text-slate-300">
                          <div className="flex items-center gap-1">
                            <Server className="w-3 h-3" />
                            <span>{result.service}</span>
                          </div>
                          {result.version && <span className="text-slate-400">{result.version}</span>}
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>{result.responseTime}ms</span>
                          </div>
                        </div>
                        {result.banner && (
                          <div className="mt-2 p-2 bg-slate-600/30 rounded text-xs font-mono text-slate-300">
                            {result.banner}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Security Recommendations */}
      {openPorts > 0 && (
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Security Recommendations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {results.filter((r) => r.status === "open" && getRiskLevel(r.port, r.service, r.status) === "high")
                .length > 0 && (
                <div className="p-3 bg-red-900/20 border border-red-700 rounded-lg">
                  <div className="flex items-center gap-2 mb-1">
                    <AlertTriangle className="w-4 h-4 text-red-400" />
                    <span className="text-red-400 font-medium">High Risk Ports Detected</span>
                  </div>
                  <p className="text-red-300 text-sm">
                    Consider closing or securing high-risk services like FTP, Telnet, RDP, or database ports.
                  </p>
                </div>
              )}

              <div className="p-3 bg-blue-900/20 border border-blue-700 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <Shield className="w-4 h-4 text-blue-400" />
                  <span className="text-blue-400 font-medium">General Security Tips</span>
                </div>
                <ul className="text-blue-300 text-sm space-y-1">
                  <li>• Close unnecessary open ports</li>
                  <li>• Keep services updated to latest versions</li>
                  <li>• Implement firewall rules to restrict access</li>
                  <li>• Use strong authentication for all services</li>
                  <li>• Monitor for unauthorized port openings</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
