"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { History, Trash2, Clock, Target, Activity, Network } from "lucide-react"

interface ScanHistoryProps {
  history: any[]
  onClearHistory: () => void
}

export default function ScanHistory({ history, onClearHistory }: ScanHistoryProps) {
  const formatDuration = (ms: number) => {
    if (ms < 1000) return `${ms}ms`
    if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`
    return `${(ms / 60000).toFixed(1)}m`
  }

  const getScanTypeLabel = (scanType: string) => {
    const types = {
      "tcp-connect": "TCP Connect",
      "tcp-syn": "TCP SYN",
      "tcp-ack": "TCP ACK",
      udp: "UDP Scan",
      "tcp-fin": "TCP FIN",
      "tcp-null": "TCP NULL",
    }
    return types[scanType as keyof typeof types] || scanType
  }

  return (
    <div className="space-y-6">
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white flex items-center gap-2">
                <History className="w-5 h-5" />
                Scan History ({history.length})
              </CardTitle>
              <CardDescription className="text-slate-400">Previous port scan results and statistics</CardDescription>
            </div>
            {history.length > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={onClearHistory}
                className="text-red-400 border-red-400 hover:bg-red-400 hover:text-white bg-transparent"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Clear History
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {history.length === 0 ? (
            <div className="text-center py-12">
              <History className="w-12 h-12 text-slate-600 mx-auto mb-4" />
              <p className="text-slate-400">No scan history yet. Complete some scans to see them here.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {history.map((scan, index) => (
                <div key={scan.id} className="p-4 bg-slate-700/30 rounded-lg border-l-4 border-l-blue-500">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <Target className="w-5 h-5 text-blue-400" />
                      <div>
                        <h4 className="text-white font-medium">{scan.target}</h4>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs">
                            {getScanTypeLabel(scan.scanType)}
                          </Badge>
                          <Badge variant="secondary" className="text-xs">
                            {scan.portRange}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-1 text-slate-400 text-sm">
                        <Clock className="w-3 h-3" />
                        {scan.timestamp}
                      </div>
                      <div className="text-slate-400 text-xs mt-1">Duration: {formatDuration(scan.duration)}</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Activity className="w-4 h-4 text-slate-400" />
                      <div>
                        <p className="text-slate-400">Ports Scanned</p>
                        <p className="text-white font-medium">{scan.portsScanned}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Network className="w-4 h-4 text-green-400" />
                      <div>
                        <p className="text-slate-400">Open Ports</p>
                        <p className="text-green-400 font-medium">{scan.openPorts}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Network className="w-4 h-4 text-yellow-400" />
                      <div>
                        <p className="text-slate-400">Filtered</p>
                        <p className="text-yellow-400 font-medium">{scan.filteredPorts}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-blue-400" />
                      <div>
                        <p className="text-slate-400">Success Rate</p>
                        <p className="text-blue-400 font-medium">
                          {Math.round(((scan.openPorts + scan.filteredPorts) / scan.portsScanned) * 100)}%
                        </p>
                      </div>
                    </div>
                  </div>

                  {scan.openPorts > 0 && (
                    <div className="mt-3 p-3 bg-slate-600/30 rounded">
                      <p className="text-slate-400 text-xs mb-2">Open Ports Found:</p>
                      <div className="flex flex-wrap gap-1">
                        {scan.results
                          .filter((r: any) => r.status === "open")
                          .slice(0, 10)
                          .map((result: any, idx: number) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {result.port}/{result.protocol}
                            </Badge>
                          ))}
                        {scan.results.filter((r: any) => r.status === "open").length > 10 && (
                          <Badge variant="secondary" className="text-xs">
                            +{scan.results.filter((r: any) => r.status === "open").length - 10} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
