"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Wifi, Globe, MapPin, Clock, Search, Copy, Check } from "lucide-react"

export default function NetworkTools() {
  const [pingTarget, setPingTarget] = useState("")
  const [pingResults, setPingResults] = useState<any[]>([])
  const [pinging, setPinging] = useState(false)

  const [tracerouteTarget, setTracerouteTarget] = useState("")
  const [tracerouteResults, setTracerouteResults] = useState<any[]>([])
  const [tracing, setTracing] = useState(false)

  const [whoisTarget, setWhoisTarget] = useState("")
  const [whoisResult, setWhoisResult] = useState<any>(null)
  const [lookingUp, setLookingUp] = useState(false)

  const [dnsTarget, setDnsTarget] = useState("")
  const [dnsResults, setDnsResults] = useState<any[]>([])
  const [resolving, setResolving] = useState(false)

  const [copied, setCopied] = useState("")

  const simulatePing = async () => {
    if (!pingTarget) return

    setPinging(true)
    setPingResults([])

    const results = []
    for (let i = 0; i < 4; i++) {
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const responseTime = Math.floor(Math.random() * 50) + 10
      const ttl = Math.floor(Math.random() * 10) + 54

      results.push({
        sequence: i + 1,
        time: responseTime,
        ttl: ttl,
        status: Math.random() > 0.1 ? "success" : "timeout",
      })

      setPingResults([...results])
    }

    setPinging(false)
  }

  const simulateTraceroute = async () => {
    if (!tracerouteTarget) return

    setTracing(true)
    setTracerouteResults([])

    const hops = [
      { hop: 1, ip: "192.168.1.1", hostname: "router.local", time: 1.2 },
      { hop: 2, ip: "10.0.0.1", hostname: "isp-gateway.net", time: 12.5 },
      { hop: 3, ip: "203.0.113.1", hostname: "core1.isp.com", time: 25.8 },
      { hop: 4, ip: "198.51.100.1", hostname: "backbone.net", time: 45.2 },
      { hop: 5, ip: "203.0.113.50", hostname: "edge.target.com", time: 67.1 },
      { hop: 6, ip: "192.0.2.100", hostname: tracerouteTarget, time: 78.3 },
    ]

    for (let i = 0; i < hops.length; i++) {
      await new Promise((resolve) => setTimeout(resolve, 1500))
      setTracerouteResults((prev) => [...prev, hops[i]])
    }

    setTracing(false)
  }

  const simulateWhoisLookup = async () => {
    if (!whoisTarget) return

    setLookingUp(true)
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setWhoisResult({
      domain: whoisTarget,
      registrar: "Example Registrar Inc.",
      registrationDate: "2020-01-15",
      expirationDate: "2025-01-15",
      nameServers: ["ns1.example.com", "ns2.example.com"],
      status: "clientTransferProhibited",
      registrant: {
        organization: "Example Organization",
        country: "US",
        state: "California",
      },
      contacts: {
        admin: "admin@example.com",
        tech: "tech@example.com",
      },
    })

    setLookingUp(false)
  }

  const simulateDnsLookup = async () => {
    if (!dnsTarget) return

    setResolving(true)
    setDnsResults([])

    await new Promise((resolve) => setTimeout(resolve, 1000))

    const records = [
      { type: "A", value: "192.0.2.1", ttl: 300 },
      { type: "A", value: "192.0.2.2", ttl: 300 },
      { type: "AAAA", value: "2001:db8::1", ttl: 300 },
      { type: "MX", value: "10 mail.example.com", ttl: 3600 },
      { type: "NS", value: "ns1.example.com", ttl: 86400 },
      { type: "NS", value: "ns2.example.com", ttl: 86400 },
      { type: "TXT", value: "v=spf1 include:_spf.example.com ~all", ttl: 300 },
    ]

    setDnsResults(records)
    setResolving(false)
  }

  const copyToClipboard = async (text: string, type: string) => {
    await navigator.clipboard.writeText(text)
    setCopied(type)
    setTimeout(() => setCopied(""), 2000)
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Ping Tool */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Wifi className="w-5 h-5" />
            Ping Tool
          </CardTitle>
          <CardDescription className="text-slate-400">Test network connectivity and latency</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Enter hostname or IP address"
              value={pingTarget}
              onChange={(e) => setPingTarget(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white"
              disabled={pinging}
            />
            <Button
              onClick={simulatePing}
              disabled={!pingTarget || pinging}
              className="bg-green-600 hover:bg-green-700"
            >
              {pinging ? "Pinging..." : "Ping"}
            </Button>
          </div>

          {pingResults.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-white font-medium">Ping Results</h4>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() =>
                    copyToClipboard(
                      pingResults
                        .map(
                          (r) =>
                            `${r.sequence}: ${r.status === "success" ? `${r.time}ms TTL=${r.ttl}` : "Request timeout"}`,
                        )
                        .join("\n"),
                      "ping",
                    )
                  }
                >
                  {copied === "ping" ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
              {pingResults.map((result, index) => (
                <div key={index} className="p-3 bg-slate-700/30 rounded flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Badge variant="outline" className="font-mono">
                      #{result.sequence}
                    </Badge>
                    <span className="text-white">
                      {result.status === "success" ? <>Reply from {pingTarget}</> : <>Request timeout</>}
                    </span>
                  </div>
                  {result.status === "success" && (
                    <div className="flex items-center gap-4 text-sm">
                      <span className="text-green-400">{result.time}ms</span>
                      <span className="text-slate-400">TTL={result.ttl}</span>
                    </div>
                  )}
                </div>
              ))}

              {!pinging && pingResults.length === 4 && (
                <div className="p-3 bg-slate-600/30 rounded">
                  <div className="text-sm text-slate-300">
                    <p>
                      Packets: Sent = 4, Received = {pingResults.filter((r) => r.status === "success").length}, Lost ={" "}
                      {pingResults.filter((r) => r.status === "timeout").length}
                    </p>
                    <p>
                      Average time:{" "}
                      {Math.round(
                        pingResults.filter((r) => r.status === "success").reduce((sum, r) => sum + r.time, 0) /
                          pingResults.filter((r) => r.status === "success").length,
                      )}
                      ms
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Traceroute Tool */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            Traceroute
          </CardTitle>
          <CardDescription className="text-slate-400">
            Trace the path packets take to reach a destination
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Enter hostname or IP address"
              value={tracerouteTarget}
              onChange={(e) => setTracerouteTarget(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white"
              disabled={tracing}
            />
            <Button
              onClick={simulateTraceroute}
              disabled={!tracerouteTarget || tracing}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {tracing ? "Tracing..." : "Trace"}
            </Button>
          </div>

          {tracerouteResults.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-white font-medium">Route to {tracerouteTarget}</h4>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() =>
                    copyToClipboard(
                      tracerouteResults.map((r) => `${r.hop}. ${r.hostname} (${r.ip}) ${r.time}ms`).join("\n"),
                      "traceroute",
                    )
                  }
                >
                  {copied === "traceroute" ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
              {tracerouteResults.map((hop, index) => (
                <div key={index} className="p-3 bg-slate-700/30 rounded flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Badge variant="outline" className="font-mono">
                      {hop.hop}
                    </Badge>
                    <div>
                      <p className="text-white">{hop.hostname}</p>
                      <p className="text-slate-400 text-sm">{hop.ip}</p>
                    </div>
                  </div>
                  <div className="text-green-400 font-mono">{hop.time}ms</div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* WHOIS Lookup */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Search className="w-5 h-5" />
            WHOIS Lookup
          </CardTitle>
          <CardDescription className="text-slate-400">Get domain registration information</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Enter domain name"
              value={whoisTarget}
              onChange={(e) => setWhoisTarget(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white"
              disabled={lookingUp}
            />
            <Button
              onClick={simulateWhoisLookup}
              disabled={!whoisTarget || lookingUp}
              className="bg-orange-600 hover:bg-orange-700"
            >
              {lookingUp ? "Looking up..." : "Lookup"}
            </Button>
          </div>

          {whoisResult && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-white font-medium">WHOIS Information</h4>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(JSON.stringify(whoisResult, null, 2), "whois")}
                >
                  {copied === "whois" ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="p-3 bg-slate-700/30 rounded">
                    <p className="text-slate-400 text-sm">Domain</p>
                    <p className="text-white font-mono">{whoisResult.domain}</p>
                  </div>
                  <div className="p-3 bg-slate-700/30 rounded">
                    <p className="text-slate-400 text-sm">Registrar</p>
                    <p className="text-white">{whoisResult.registrar}</p>
                  </div>
                  <div className="p-3 bg-slate-700/30 rounded">
                    <p className="text-slate-400 text-sm">Registration Date</p>
                    <p className="text-white">{whoisResult.registrationDate}</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="p-3 bg-slate-700/30 rounded">
                    <p className="text-slate-400 text-sm">Expiration Date</p>
                    <p className="text-white">{whoisResult.expirationDate}</p>
                  </div>
                  <div className="p-3 bg-slate-700/30 rounded">
                    <p className="text-slate-400 text-sm">Status</p>
                    <Badge variant="secondary">{whoisResult.status}</Badge>
                  </div>
                  <div className="p-3 bg-slate-700/30 rounded">
                    <p className="text-slate-400 text-sm">Name Servers</p>
                    <div className="space-y-1">
                      {whoisResult.nameServers.map((ns: string, idx: number) => (
                        <p key={idx} className="text-white font-mono text-sm">
                          {ns}
                        </p>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* DNS Lookup */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Globe className="w-5 h-5" />
            DNS Lookup
          </CardTitle>
          <CardDescription className="text-slate-400">Resolve DNS records for a domain</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Enter domain name"
              value={dnsTarget}
              onChange={(e) => setDnsTarget(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white"
              disabled={resolving}
            />
            <Button
              onClick={simulateDnsLookup}
              disabled={!dnsTarget || resolving}
              className="bg-cyan-600 hover:bg-cyan-700"
            >
              {resolving ? "Resolving..." : "Resolve"}
            </Button>
          </div>

          {dnsResults.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-white font-medium">DNS Records for {dnsTarget}</h4>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() =>
                    copyToClipboard(dnsResults.map((r) => `${r.type}\t${r.value}\t${r.ttl}`).join("\n"), "dns")
                  }
                >
                  {copied === "dns" ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>

              {dnsResults.map((record, index) => (
                <div key={index} className="p-3 bg-slate-700/30 rounded flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Badge variant="outline" className="font-mono min-w-[60px]">
                      {record.type}
                    </Badge>
                    <span className="text-white font-mono">{record.value}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-slate-400">
                    <Clock className="w-3 h-3" />
                    <span>TTL: {record.ttl}s</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
