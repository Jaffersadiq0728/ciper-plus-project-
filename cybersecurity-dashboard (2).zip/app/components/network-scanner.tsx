"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Scan, Wifi, AlertTriangle } from "lucide-react"

export default function NetworkScanner() {
  const [target, setTarget] = useState("")
  const [scanning, setScanning] = useState(false)
  const [progress, setProgress] = useState(0)
  const [results, setResults] = useState<any[]>([])

  const commonPorts = [
    { port: 21, service: "FTP", risk: "medium" },
    { port: 22, service: "SSH", risk: "low" },
    { port: 23, service: "Telnet", risk: "high" },
    { port: 25, service: "SMTP", risk: "medium" },
    { port: 53, service: "DNS", risk: "low" },
    { port: 80, service: "HTTP", risk: "low" },
    { port: 110, service: "POP3", risk: "medium" },
    { port: 143, service: "IMAP", risk: "medium" },
    { port: 443, service: "HTTPS", risk: "low" },
    { port: 993, service: "IMAPS", risk: "low" },
    { port: 995, service: "POP3S", risk: "low" },
    { port: 3389, service: "RDP", risk: "high" },
    { port: 5432, service: "PostgreSQL", risk: "high" },
    { port: 3306, service: "MySQL", risk: "high" },
  ]

  const simulateScan = async () => {
    if (!target) return

    setScanning(true)
    setProgress(0)
    setResults([])

    // Simulate scanning progress
    for (let i = 0; i <= 100; i += 10) {
      setProgress(i)
      await new Promise((resolve) => setTimeout(resolve, 200))
    }

    // Simulate random open ports
    const openPorts = commonPorts
      .filter(() => Math.random() > 0.7)
      .map((port) => ({
        ...port,
        status: "open",
        banner: `${port.service} service running`,
        timestamp: new Date().toLocaleTimeString(),
      }))

    setResults(openPorts)
    setScanning(false)
  }

  return (
    <div className="space-y-6">
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Scan className="w-5 h-5" />
            Network Port Scanner
          </CardTitle>
          <CardDescription className="text-slate-400">
            Scan for open ports and services (Educational simulation)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Enter IP address or hostname (e.g., 192.168.1.1)"
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white"
              disabled={scanning}
            />
            <Button onClick={simulateScan} disabled={scanning || !target} className="bg-cyan-600 hover:bg-cyan-700">
              {scanning ? "Scanning..." : "Scan"}
            </Button>
          </div>

          {scanning && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-slate-300">Scanning ports...</span>
                <span className="text-slate-300">{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}

          {results.length > 0 && (
            <div className="space-y-4">
              <h4 className="text-white font-medium">Scan Results for {target}:</h4>
              <div className="space-y-2">
                {results.map((result, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-slate-700/30 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Wifi className="w-4 h-4 text-green-400" />
                      <div>
                        <p className="text-white text-sm">
                          Port {result.port} - {result.service}
                        </p>
                        <p className="text-slate-400 text-xs">{result.banner}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge
                        variant={
                          result.risk === "high" ? "destructive" : result.risk === "medium" ? "secondary" : "default"
                        }
                      >
                        {result.risk} risk
                      </Badge>
                      <Badge variant="outline" className="text-green-400 border-green-400">
                        OPEN
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>

              {results.some((r) => r.risk === "high") && (
                <div className="p-4 bg-red-900/20 border border-red-700 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertTriangle className="w-4 h-4 text-red-400" />
                    <span className="text-red-400 font-medium">Security Warning</span>
                  </div>
                  <p className="text-red-300 text-sm">
                    High-risk ports detected. Consider closing unnecessary services or implementing proper security
                    measures.
                  </p>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Common Ports Reference</CardTitle>
          <CardDescription className="text-slate-400">
            Reference guide for common network ports and their security implications
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {commonPorts.map((port, index) => (
              <div key={index} className="flex items-center justify-between p-2 bg-slate-700/20 rounded">
                <div>
                  <span className="text-white font-mono">{port.port}</span>
                  <span className="text-slate-300 ml-2">{port.service}</span>
                </div>
                <Badge
                  variant={port.risk === "high" ? "destructive" : port.risk === "medium" ? "secondary" : "default"}
                >
                  {port.risk}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
