"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, XCircle, AlertTriangle, Shield, RefreshCw } from "lucide-react"

export default function SecurityAudit() {
  const [auditRunning, setAuditRunning] = useState(false)
  const [auditProgress, setAuditProgress] = useState(0)
  const [auditResults, setAuditResults] = useState<any[]>([])
  const [overallScore, setOverallScore] = useState(0)

  const auditChecks = [
    {
      category: "Authentication",
      checks: [
        {
          name: "Strong password policy",
          status: "pass",
          description: "Minimum 8 characters with complexity requirements",
        },
        { name: "Multi-factor authentication", status: "fail", description: "MFA not enabled for admin accounts" },
        { name: "Account lockout policy", status: "pass", description: "Account locks after 5 failed attempts" },
        {
          name: "Session timeout",
          status: "warning",
          description: "Session timeout set to 4 hours (recommended: 2 hours)",
        },
      ],
    },
    {
      category: "Network Security",
      checks: [
        {
          name: "Firewall configuration",
          status: "pass",
          description: "Firewall properly configured with default deny",
        },
        { name: "Open ports audit", status: "warning", description: "3 unnecessary ports detected" },
        { name: "SSL/TLS configuration", status: "pass", description: "Strong encryption protocols enabled" },
        { name: "Network segmentation", status: "fail", description: "Critical systems not properly segmented" },
      ],
    },
    {
      category: "Data Protection",
      checks: [
        { name: "Data encryption at rest", status: "pass", description: "AES-256 encryption implemented" },
        { name: "Data encryption in transit", status: "pass", description: "TLS 1.3 enforced for all connections" },
        { name: "Backup encryption", status: "warning", description: "Backups encrypted but key rotation needed" },
        { name: "Data retention policy", status: "pass", description: "Automated data retention and deletion" },
      ],
    },
    {
      category: "Access Control",
      checks: [
        {
          name: "Principle of least privilege",
          status: "warning",
          description: "Some users have excessive permissions",
        },
        { name: "Regular access reviews", status: "fail", description: "Last access review was 8 months ago" },
        { name: "Privileged account management", status: "pass", description: "Privileged accounts properly managed" },
        { name: "Role-based access control", status: "pass", description: "RBAC implemented and maintained" },
      ],
    },
    {
      category: "Monitoring & Logging",
      checks: [
        { name: "Security event logging", status: "pass", description: "Comprehensive security logging enabled" },
        { name: "Log retention policy", status: "pass", description: "Logs retained for 12 months" },
        {
          name: "Real-time monitoring",
          status: "warning",
          description: "Monitoring in place but alerting needs tuning",
        },
        { name: "Incident response plan", status: "fail", description: "Incident response plan outdated" },
      ],
    },
  ]

  const runAudit = async () => {
    setAuditRunning(true)
    setAuditProgress(0)
    setAuditResults([])

    // Simulate audit progress
    for (let i = 0; i <= 100; i += 5) {
      setAuditProgress(i)
      await new Promise((resolve) => setTimeout(resolve, 100))
    }

    // Calculate results
    const results = auditChecks.map((category) => {
      const totalChecks = category.checks.length
      const passedChecks = category.checks.filter((check) => check.status === "pass").length
      const score = Math.round((passedChecks / totalChecks) * 100)

      return {
        ...category,
        score,
        totalChecks,
        passedChecks,
        failedChecks: category.checks.filter((check) => check.status === "fail").length,
        warningChecks: category.checks.filter((check) => check.status === "warning").length,
      }
    })

    const totalChecks = results.reduce((sum, cat) => sum + cat.totalChecks, 0)
    const totalPassed = results.reduce((sum, cat) => sum + cat.passedChecks, 0)
    const overallScore = Math.round((totalPassed / totalChecks) * 100)

    setAuditResults(results)
    setOverallScore(overallScore)
    setAuditRunning(false)
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pass":
        return <CheckCircle className="w-4 h-4 text-green-400" />
      case "fail":
        return <XCircle className="w-4 h-4 text-red-400" />
      case "warning":
        return <AlertTriangle className="w-4 h-4 text-yellow-400" />
      default:
        return null
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pass":
        return <Badge className="bg-green-600">Pass</Badge>
      case "fail":
        return <Badge variant="destructive">Fail</Badge>
      case "warning":
        return <Badge variant="secondary">Warning</Badge>
      default:
        return null
    }
  }

  return (
    <div className="space-y-6">
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Shield className="w-5 h-5" />
            Security Audit Dashboard
          </CardTitle>
          <CardDescription className="text-slate-400">Comprehensive security posture assessment</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button onClick={runAudit} disabled={auditRunning} className="w-full bg-cyan-600 hover:bg-cyan-700">
            {auditRunning ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                Running Audit...
              </>
            ) : (
              <>
                <Shield className="w-4 h-4 mr-2" />
                Start Security Audit
              </>
            )}
          </Button>

          {auditRunning && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-slate-300">Scanning security controls...</span>
                <span className="text-slate-300">{auditProgress}%</span>
              </div>
              <Progress value={auditProgress} className="h-2" />
            </div>
          )}

          {auditResults.length > 0 && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-700/30 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-white font-medium">Overall Security Score</h3>
                  <Badge variant={overallScore >= 80 ? "default" : overallScore >= 60 ? "secondary" : "destructive"}>
                    {overallScore}%
                  </Badge>
                </div>
                <Progress value={overallScore} className="h-3" />
                <p className="text-slate-400 text-sm mt-2">
                  {overallScore >= 80
                    ? "Good security posture"
                    : overallScore >= 60
                      ? "Moderate security posture - improvements needed"
                      : "Poor security posture - immediate action required"}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {auditResults.map((category, index) => (
                  <Card key={index} className="bg-slate-700/30 border-slate-600">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-white text-sm">{category.category}</CardTitle>
                      <div className="flex items-center gap-2">
                        <Progress value={category.score} className="h-2 flex-1" />
                        <span className="text-white text-sm font-medium">{category.score}%</span>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="flex justify-between text-xs text-slate-400">
                        <span className="text-green-400">{category.passedChecks} passed</span>
                        <span className="text-yellow-400">{category.warningChecks} warnings</span>
                        <span className="text-red-400">{category.failedChecks} failed</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {auditResults.length > 0 && (
        <div className="space-y-4">
          {auditResults.map((category, categoryIndex) => (
            <Card key={categoryIndex} className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white text-lg">{category.category}</CardTitle>
                <CardDescription className="text-slate-400">
                  {category.passedChecks}/{category.totalChecks} checks passed
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {category.checks.map((check: any, checkIndex: number) => (
                    <div key={checkIndex} className="flex items-start gap-3 p-3 bg-slate-700/20 rounded-lg">
                      {getStatusIcon(check.status)}
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="text-white font-medium text-sm">{check.name}</h4>
                          {getStatusBadge(check.status)}
                        </div>
                        <p className="text-slate-400 text-xs">{check.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
