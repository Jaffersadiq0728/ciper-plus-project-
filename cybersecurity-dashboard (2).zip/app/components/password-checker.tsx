"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Eye, EyeOff, RefreshCw, Copy, Check } from "lucide-react"

export default function PasswordChecker() {
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [generatedPassword, setGeneratedPassword] = useState("")
  const [copied, setCopied] = useState(false)

  const checkPasswordStrength = (pwd: string) => {
    let score = 0
    const checks = {
      length: pwd.length >= 8,
      uppercase: /[A-Z]/.test(pwd),
      lowercase: /[a-z]/.test(pwd),
      numbers: /\d/.test(pwd),
      symbols: /[!@#$%^&*(),.?":{}|<>]/.test(pwd),
      noCommon: !["password", "123456", "qwerty", "admin"].includes(pwd.toLowerCase()),
    }

    Object.values(checks).forEach((check) => check && score++)

    return {
      score: (score / 6) * 100,
      strength: score < 3 ? "Weak" : score < 5 ? "Medium" : "Strong",
      checks,
    }
  }

  const generatePassword = () => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*"
    let result = ""
    for (let i = 0; i < 16; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    setGeneratedPassword(result)
  }

  const copyToClipboard = async (text: string) => {
    await navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const { score, strength, checks } = checkPasswordStrength(password)

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Password Strength Checker</CardTitle>
          <CardDescription className="text-slate-400">Test your password strength and security</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="relative">
            <Input
              type={showPassword ? "text" : "password"}
              placeholder="Enter password to check..."
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white pr-10"
            />
            <Button
              variant="ghost"
              size="sm"
              className="absolute right-2 top-1/2 transform -translate-y-1/2"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </Button>
          </div>

          {password && (
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-white text-sm">Strength: {strength}</span>
                  <Badge
                    variant={strength === "Strong" ? "default" : strength === "Medium" ? "secondary" : "destructive"}
                  >
                    {Math.round(score)}%
                  </Badge>
                </div>
                <Progress value={score} className="h-2" />
              </div>

              <div className="space-y-2">
                <h4 className="text-white font-medium">Security Checks:</h4>
                {Object.entries(checks).map(([key, passed]) => (
                  <div key={key} className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${passed ? "bg-green-400" : "bg-red-400"}`} />
                    <span className={`text-sm ${passed ? "text-green-400" : "text-red-400"}`}>
                      {key === "length" && "At least 8 characters"}
                      {key === "uppercase" && "Contains uppercase letters"}
                      {key === "lowercase" && "Contains lowercase letters"}
                      {key === "numbers" && "Contains numbers"}
                      {key === "symbols" && "Contains special characters"}
                      {key === "noCommon" && "Not a common password"}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Password Generator</CardTitle>
          <CardDescription className="text-slate-400">Generate secure passwords</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <Button onClick={generatePassword} className="w-full bg-cyan-600 hover:bg-cyan-700">
            <RefreshCw className="w-4 h-4 mr-2" />
            Generate Secure Password
          </Button>

          {generatedPassword && (
            <div className="space-y-4">
              <div className="relative">
                <Input
                  value={generatedPassword}
                  readOnly
                  className="bg-slate-700 border-slate-600 text-white pr-10 font-mono"
                />
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute right-2 top-1/2 transform -translate-y-1/2"
                  onClick={() => copyToClipboard(generatedPassword)}
                >
                  {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>

              <div className="p-4 bg-slate-700/30 rounded-lg">
                <h4 className="text-white font-medium mb-2">Password Analysis:</h4>
                <div className="text-sm text-slate-300">
                  <p>Length: {generatedPassword.length} characters</p>
                  <p>Entropy: ~{Math.round(generatedPassword.length * Math.log2(94))} bits</p>
                  <p>Time to crack: {">"} 1 trillion years</p>
                </div>
              </div>
            </div>
          )}

          <div className="space-y-2">
            <h4 className="text-white font-medium">Password Tips:</h4>
            <ul className="text-sm text-slate-300 space-y-1">
              <li>• Use at least 12 characters</li>
              <li>• Mix uppercase, lowercase, numbers, symbols</li>
              <li>• Avoid dictionary words</li>
              <li>• Use unique passwords for each account</li>
              <li>• Consider using a password manager</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
