"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search, Database, Shield, AlertTriangle, Info } from "lucide-react"

export default function PortDatabase() {
  const [searchTerm, setSearchTerm] = useState("")

  const portDatabase = [
    {
      port: 20,
      service: "FTP-DATA",
      protocol: "TCP",
      description: "File Transfer Protocol Data",
      risk: "medium",
      rfc: "RFC 959",
    },
    {
      port: 21,
      service: "FTP",
      protocol: "TCP",
      description: "File Transfer Protocol Control",
      risk: "high",
      rfc: "RFC 959",
    },
    { port: 22, service: "SSH", protocol: "TCP", description: "Secure Shell Protocol", risk: "low", rfc: "RFC 4251" },
    { port: 23, service: "Telnet", protocol: "TCP", description: "Telnet Protocol", risk: "high", rfc: "RFC 854" },
    {
      port: 25,
      service: "SMTP",
      protocol: "TCP",
      description: "Simple Mail Transfer Protocol",
      risk: "medium",
      rfc: "RFC 5321",
    },
    { port: 53, service: "DNS", protocol: "TCP/UDP", description: "Domain Name System", risk: "low", rfc: "RFC 1035" },
    {
      port: 67,
      service: "DHCP",
      protocol: "UDP",
      description: "Dynamic Host Configuration Protocol Server",
      risk: "low",
      rfc: "RFC 2131",
    },
    {
      port: 68,
      service: "DHCP",
      protocol: "UDP",
      description: "Dynamic Host Configuration Protocol Client",
      risk: "low",
      rfc: "RFC 2131",
    },
    {
      port: 69,
      service: "TFTP",
      protocol: "UDP",
      description: "Trivial File Transfer Protocol",
      risk: "medium",
      rfc: "RFC 1350",
    },
    {
      port: 80,
      service: "HTTP",
      protocol: "TCP",
      description: "Hypertext Transfer Protocol",
      risk: "low",
      rfc: "RFC 2616",
    },
    {
      port: 110,
      service: "POP3",
      protocol: "TCP",
      description: "Post Office Protocol Version 3",
      risk: "medium",
      rfc: "RFC 1939",
    },
    {
      port: 111,
      service: "RPC",
      protocol: "TCP/UDP",
      description: "Remote Procedure Call",
      risk: "high",
      rfc: "RFC 1057",
    },
    { port: 123, service: "NTP", protocol: "UDP", description: "Network Time Protocol", risk: "low", rfc: "RFC 5905" },
    {
      port: 135,
      service: "RPC",
      protocol: "TCP",
      description: "Microsoft RPC Endpoint Mapper",
      risk: "high",
      rfc: "N/A",
    },
    {
      port: 137,
      service: "NetBIOS-NS",
      protocol: "UDP",
      description: "NetBIOS Name Service",
      risk: "medium",
      rfc: "RFC 1002",
    },
    {
      port: 138,
      service: "NetBIOS-DGM",
      protocol: "UDP",
      description: "NetBIOS Datagram Service",
      risk: "medium",
      rfc: "RFC 1002",
    },
    {
      port: 139,
      service: "NetBIOS-SSN",
      protocol: "TCP",
      description: "NetBIOS Session Service",
      risk: "high",
      rfc: "RFC 1002",
    },
    {
      port: 143,
      service: "IMAP",
      protocol: "TCP",
      description: "Internet Message Access Protocol",
      risk: "medium",
      rfc: "RFC 3501",
    },
    {
      port: 161,
      service: "SNMP",
      protocol: "UDP",
      description: "Simple Network Management Protocol",
      risk: "medium",
      rfc: "RFC 1157",
    },
    { port: 162, service: "SNMP-TRAP", protocol: "UDP", description: "SNMP Trap", risk: "medium", rfc: "RFC 1157" },
    {
      port: 389,
      service: "LDAP",
      protocol: "TCP",
      description: "Lightweight Directory Access Protocol",
      risk: "medium",
      rfc: "RFC 4511",
    },
    { port: 443, service: "HTTPS", protocol: "TCP", description: "HTTP Secure", risk: "low", rfc: "RFC 2818" },
    { port: 445, service: "SMB", protocol: "TCP", description: "Server Message Block", risk: "high", rfc: "N/A" },
    { port: 465, service: "SMTPS", protocol: "TCP", description: "SMTP Secure", risk: "low", rfc: "RFC 8314" },
    {
      port: 514,
      service: "Syslog",
      protocol: "UDP",
      description: "System Logging Protocol",
      risk: "medium",
      rfc: "RFC 3164",
    },
    {
      port: 587,
      service: "SMTP",
      protocol: "TCP",
      description: "SMTP Message Submission",
      risk: "medium",
      rfc: "RFC 6409",
    },
    { port: 636, service: "LDAPS", protocol: "TCP", description: "LDAP Secure", risk: "low", rfc: "RFC 4513" },
    { port: 993, service: "IMAPS", protocol: "TCP", description: "IMAP Secure", risk: "low", rfc: "RFC 8314" },
    { port: 995, service: "POP3S", protocol: "TCP", description: "POP3 Secure", risk: "low", rfc: "RFC 8314" },
    { port: 1433, service: "MSSQL", protocol: "TCP", description: "Microsoft SQL Server", risk: "high", rfc: "N/A" },
    { port: 1521, service: "Oracle", protocol: "TCP", description: "Oracle Database", risk: "high", rfc: "N/A" },
    {
      port: 1723,
      service: "PPTP",
      protocol: "TCP",
      description: "Point-to-Point Tunneling Protocol",
      risk: "medium",
      rfc: "RFC 2637",
    },
    { port: 3306, service: "MySQL", protocol: "TCP", description: "MySQL Database", risk: "high", rfc: "N/A" },
    { port: 3389, service: "RDP", protocol: "TCP", description: "Remote Desktop Protocol", risk: "high", rfc: "N/A" },
    {
      port: 5432,
      service: "PostgreSQL",
      protocol: "TCP",
      description: "PostgreSQL Database",
      risk: "high",
      rfc: "N/A",
    },
    {
      port: 5900,
      service: "VNC",
      protocol: "TCP",
      description: "Virtual Network Computing",
      risk: "high",
      rfc: "RFC 6143",
    },
    { port: 6379, service: "Redis", protocol: "TCP", description: "Redis Database", risk: "high", rfc: "N/A" },
    { port: 8080, service: "HTTP-ALT", protocol: "TCP", description: "HTTP Alternative", risk: "medium", rfc: "N/A" },
    { port: 8443, service: "HTTPS-ALT", protocol: "TCP", description: "HTTPS Alternative", risk: "medium", rfc: "N/A" },
    {
      port: 9200,
      service: "Elasticsearch",
      protocol: "TCP",
      description: "Elasticsearch REST API",
      risk: "high",
      rfc: "N/A",
    },
    { port: 27017, service: "MongoDB", protocol: "TCP", description: "MongoDB Database", risk: "high", rfc: "N/A" },
  ]

  const filteredPorts = portDatabase.filter(
    (port) =>
      port.port.toString().includes(searchTerm) ||
      port.service.toLowerCase().includes(searchTerm.toLowerCase()) ||
      port.description.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const getRiskIcon = (risk: string) => {
    switch (risk) {
      case "high":
        return <AlertTriangle className="w-4 h-4 text-red-400" />
      case "medium":
        return <Shield className="w-4 h-4 text-yellow-400" />
      case "low":
        return <Info className="w-4 h-4 text-green-400" />
      default:
        return <Info className="w-4 h-4 text-slate-400" />
    }
  }

  const getRiskBadge = (risk: string) => {
    switch (risk) {
      case "high":
        return <Badge variant="destructive">High Risk</Badge>
      case "medium":
        return <Badge variant="secondary">Medium Risk</Badge>
      case "low":
        return <Badge className="bg-green-600">Low Risk</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  const riskStats = {
    high: portDatabase.filter((p) => p.risk === "high").length,
    medium: portDatabase.filter((p) => p.risk === "medium").length,
    low: portDatabase.filter((p) => p.risk === "low").length,
  }

  return (
    <div className="space-y-6">
      {/* Database Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Total Ports</p>
                <p className="text-2xl font-bold text-white">{portDatabase.length}</p>
              </div>
              <Database className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">High Risk</p>
                <p className="text-2xl font-bold text-red-400">{riskStats.high}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Medium Risk</p>
                <p className="text-2xl font-bold text-yellow-400">{riskStats.medium}</p>
              </div>
              <Shield className="w-8 h-8 text-yellow-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Low Risk</p>
                <p className="text-2xl font-bold text-green-400">{riskStats.low}</p>
              </div>
              <Info className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Port Database */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Database className="w-5 h-5" />
            Port Database ({filteredPorts.length})
          </CardTitle>
          <CardDescription className="text-slate-400">
            Comprehensive database of common network ports and services
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Search ports, services, or descriptions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white pl-10"
            />
          </div>

          {/* Port List */}
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {filteredPorts.map((port, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-4 bg-slate-700/30 rounded-lg hover:bg-slate-700/50 transition-colors"
              >
                <div className="flex items-center gap-4">
                  {getRiskIcon(port.risk)}
                  <div>
                    <div className="flex items-center gap-3">
                      <span className="text-white font-mono text-lg">
                        {port.port}/{port.protocol}
                      </span>
                      <span className="text-blue-400 font-medium">{port.service}</span>
                      {getRiskBadge(port.risk)}
                    </div>
                    <p className="text-slate-300 text-sm mt-1">{port.description}</p>
                    <div className="flex items-center gap-4 mt-2 text-xs text-slate-400">
                      <span>RFC: {port.rfc}</span>
                      <span>Protocol: {port.protocol}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredPorts.length === 0 && (
            <div className="text-center py-8">
              <Database className="w-12 h-12 text-slate-600 mx-auto mb-4" />
              <p className="text-slate-400">No ports match your search criteria.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Security Information */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Shield className="w-5 h-5" />
            Port Security Guidelines
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-red-900/20 border border-red-700 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="w-4 h-4 text-red-400" />
                <span className="text-red-400 font-medium">High Risk Ports</span>
              </div>
              <p className="text-red-300 text-sm mb-2">
                These ports should be carefully secured or closed if not needed:
              </p>
              <ul className="text-red-300 text-xs space-y-1">
                <li>• Database ports (3306, 5432, 1433)</li>
                <li>• Remote access (3389, 5900, 22)</li>
                <li>• File sharing (21, 445, 139)</li>
                <li>• Legacy protocols (23, 111)</li>
              </ul>
            </div>

            <div className="p-4 bg-yellow-900/20 border border-yellow-700 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Shield className="w-4 h-4 text-yellow-400" />
                <span className="text-yellow-400 font-medium">Medium Risk Ports</span>
              </div>
              <p className="text-yellow-300 text-sm mb-2">Monitor and secure these commonly targeted ports:</p>
              <ul className="text-yellow-300 text-xs space-y-1">
                <li>• Email services (25, 110, 143)</li>
                <li>• Network management (161, 162)</li>
                <li>• Alternative web ports (8080, 8443)</li>
                <li>• Directory services (389)</li>
              </ul>
            </div>

            <div className="p-4 bg-green-900/20 border border-green-700 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Info className="w-4 h-4 text-green-400" />
                <span className="text-green-400 font-medium">Low Risk Ports</span>
              </div>
              <p className="text-green-300 text-sm mb-2">Generally safe but still require proper configuration:</p>
              <ul className="text-green-300 text-xs space-y-1">
                <li>• Web services (80, 443)</li>
                <li>• Secure email (993, 995, 465)</li>
                <li>• DNS (53)</li>
                <li>• Time services (123)</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
