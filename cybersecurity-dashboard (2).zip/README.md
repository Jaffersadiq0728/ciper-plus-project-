# Web Port Scanner - Professional Network Security Tool

A comprehensive web-based port scanner built with Next.js and React that provides professional-grade network scanning capabilities, service detection, and security analysis tools.

## 🚀 Features

### 🔍 **Advanced Port Scanning**
- **Multiple Scan Types**: TCP Connect, SYN, ACK, UDP, FIN, and NULL scans
- **Flexible Port Ranges**: Top 100/1000 ports, well-known ports, or custom ranges
- **Service Detection**: Automatic identification of running services
- **Version Detection**: Banner grabbing and version identification
- **Speed Control**: Configurable scan speeds (slow/normal/fast)

### 📊 **Comprehensive Results Analysis**
- **Real-time Progress**: Live scanning progress with current port display
- **Detailed Results**: Port status, service info, response times, and banners
- **Risk Assessment**: Automatic risk level classification
- **Export Capabilities**: CSV export and clipboard copy functionality
- **Advanced Filtering**: Search and filter results by status, protocol, or service

### 📚 **Port Database & Reference**
- **Comprehensive Port Database**: 40+ common ports with detailed information
- **Risk Classifications**: High/Medium/Low risk categorization
- **RFC References**: Official protocol documentation links
- **Security Guidelines**: Best practices for each port type

### 📈 **Scan History & Analytics**
- **Persistent History**: Track all previous scans with detailed statistics
- **Performance Metrics**: Success rates, duration tracking, and trend analysis
- **Quick Replay**: Easy re-scanning of previous targets
- **Export History**: Full scan history export capabilities

### 🛠️ **Network Diagnostic Tools**
- **Ping Tool**: Network connectivity testing with latency measurement
- **Traceroute**: Path discovery and hop-by-hop analysis
- **WHOIS Lookup**: Domain registration and ownership information
- **DNS Resolution**: Complete DNS record lookup (A, AAAA, MX, NS, TXT)

### 🎨 **Professional Interface**
- **Dark Theme**: Modern, eye-friendly dark interface
- **Responsive Design**: Works perfectly on desktop, tablet, and mobile
- **Real-time Updates**: Live progress indicators and status updates
- **Intuitive Navigation**: Tabbed interface with logical organization

## 🛡️ Security & Educational Focus

This tool is designed for **educational purposes** and **authorized security testing only**. It simulates real port scanning behavior while running safely in a web browser environment.

### ⚠️ **Important Disclaimers**
- **Educational Use Only**: This tool is for learning network security concepts
- **Authorization Required**: Only scan systems you own or have explicit permission to test
- **Simulated Results**: Actual scanning is simulated for browser compatibility
- **No Malicious Intent**: Not designed for unauthorized network reconnaissance

## 🚀 **Getting Started**

### Prerequisites
- Node.js 18 or higher
- Modern web browser with JavaScript enabled

### Installation

1. **Clone the repository**
\`\`\`bash
git clone https://github.com/yourusername/web-port-scanner.git
cd web-port-scanner
\`\`\`

2. **Install dependencies**
\`\`\`bash
npm install
# or
yarn install
\`\`\`

3. **Start the development server**
\`\`\`bash
npm run dev
# or
yarn dev
\`\`\`

4. **Open your browser**
Navigate to [http://localhost:3000](http://localhost:3000)

## 📖 **How to Use**

### 1. **Basic Port Scan**
- Enter target IP address or hostname
- Select scan type (TCP Connect recommended for beginners)
- Choose port range (Top 100 ports for quick scan)
- Click "Start Scan" and monitor progress

### 2. **Advanced Scanning**
- Use custom port ranges for specific services
- Enable service and version detection
- Adjust scan speed based on stealth requirements
- Review detailed results with risk assessments

### 3. **Network Diagnostics**
- Use Ping tool to test basic connectivity
- Run Traceroute to analyze network path
- Perform WHOIS lookups for domain information
- Resolve DNS records for comprehensive analysis

### 4. **Results Analysis**
- Filter results by status, protocol, or service
- Export findings to CSV for reporting
- Review security recommendations
- Track scan history for trend analysis

## 🏗️ **Technical Architecture**

### **Frontend Stack**
- **Next.js 14**: React framework with App Router
- **TypeScript**: Type-safe development
- **Tailwind CSS**: Utility-first styling
- **shadcn/ui**: Modern component library
- **Lucide React**: Professional icon set

### **Key Components**
\`\`\`
app/
├── components/
│   ├── port-scanner.tsx      # Main scanning interface
│   ├── scan-results.tsx      # Results display and analysis
│   ├── port-database.tsx     # Port reference database
│   ├── scan-history.tsx      # Historical scan tracking
│   └── network-tools.tsx     # Additional network utilities
├── page.tsx                  # Main dashboard
└── layout.tsx               # Application layout
\`\`\`

### **Simulation Logic**
The scanner uses sophisticated algorithms to simulate realistic port scanning behavior:
- **Weighted Randomization**: Realistic open/closed/filtered port distributions
- **Service Simulation**: Accurate service banners and version strings
- **Timing Simulation**: Realistic response times and scan durations
- **Progressive Results**: Real-time result updates during scanning

## 🔧 **Configuration Options**

### **Scan Types**
- **TCP Connect**: Full three-way handshake (most reliable)
- **TCP SYN**: Half-open scan (faster, more stealthy)
- **TCP ACK**: Firewall detection and mapping
- **UDP**: User Datagram Protocol scanning
- **TCP FIN/NULL**: Advanced stealth techniques

### **Port Ranges**
- **Top 100**: Most commonly used ports
- **Top 1000**: Extended common port list
- **Well-known (1-1023)**: All registered system ports
- **Custom**: User-defined port lists or ranges

### **Detection Options**
- **Service Detection**: Identify running services
- **Version Detection**: Extract version information
- **OS Detection**: Operating system fingerprinting (experimental)

## 📊 **Sample Output**

\`\`\`
Port Scan Results for example.com:
┌──────┬──────────┬────────┬─────────────┬──────────────┬──────────┐
│ Port │ Protocol │ Status │ Service     │ Version      │ Risk     │
├──────┼──────────┼────────┼─────────────┼──────────────┼──────────┤
│ 22   │ TCP      │ Open   │ SSH         │ OpenSSH 8.9  │ Low      │
│ 80   │ TCP      │ Open   │ HTTP        │ Apache/2.4.41│ Low      │
│ 443  │ TCP      │ Open   │ HTTPS       │ Apache/2.4.41│ Low      │
│ 3306 │ TCP      │ Open   │ MySQL       │ MySQL 8.0.28 │ High     │
└──────┴──────────┴────────┴─────────────┴──────────────┴──────────┘

Security Recommendations:
⚠️  High-risk MySQL port detected on 3306
✅ Web services properly configured with HTTPS
🔒 SSH service appears to be up-to-date
\`\`\`

## 🤝 **Contributing**

We welcome contributions! Please follow these guidelines:

1. **Fork the repository**
2. **Create a feature branch**: `git checkout -b feature/amazing-feature`
3. **Commit changes**: `git commit -m 'Add amazing feature'`
4. **Push to branch**: `git push origin feature/amazing-feature`
5. **Open a Pull Request**

### **Development Guidelines**
- Follow TypeScript best practices
- Maintain responsive design principles
- Add appropriate error handling
- Include comprehensive comments
- Test across different browsers

## 📄 **License**

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 **Acknowledgments**

- **shadcn/ui** for the excellent component library
- **Lucide** for the professional icon set
- **Tailwind CSS** for the utility-first CSS framework
- **Next.js** team for the amazing React framework
- **Security community** for inspiration and best practices

## 📞 **Support & Contact**

- **Issues**: [GitHub Issues](https://github.com/yourusername/web-port-scanner/issues)
- **Discussions**: [GitHub Discussions](https://github.com/yourusername/web-port-scanner/discussions)
- **Security**: For security-related issues, please email security@example.com

---

**⚠️ Legal Notice**: This tool is for educational and authorized testing purposes only. Users are responsible for complying with all applicable laws and regulations. Unauthorized network scanning may be illegal in your jurisdiction.

**🛡️ Ethical Use**: Always obtain proper authorization before scanning networks or systems you do not own. Respect privacy and security boundaries.
